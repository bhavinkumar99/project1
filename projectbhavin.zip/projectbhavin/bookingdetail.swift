

import UIKit

class bookingdetail: NSObject {
    
    func dml(query : String) -> Bool {
        var data:Bool = false
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let  path = arr[0]
        let fullpath = path.appending("/booking.db")
        print(fullpath)
        var db1: OpaquePointer? = nil
        if sqlite3_open(fullpath, &db1) == SQLITE_OK {
            var db2: OpaquePointer? = nil
            if sqlite3_prepare_v2(db1, query, -1, &db2, nil) == SQLITE_OK{
                sqlite3_step(db2)
                data = true
                sqlite3_finalize(db2)
            }
            sqlite3_close(db1)
        }
        return data
    }
    func getdata(query: String) -> [Any] {
        
        var main:[Any] = []
        var data:Bool = false
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let  path = arr[0]
        let fullpath = path.appending("/booking.db")
        print(fullpath)
        var db1: OpaquePointer! = nil
        if sqlite3_open(fullpath, &db1) == SQLITE_OK {
            var db2: OpaquePointer! = nil
            if sqlite3_prepare_v2(db1, query, -1, &db2, nil) == SQLITE_OK{
                while sqlite3_step(db2) == SQLITE_ROW {
                   var tmpt:[String] = []
                    let b_id = String(cString: sqlite3_column_text(db2, 0))
                    let cb_cname = String(cString: sqlite3_column_text(db2, 1))
                    let cb_siters = String(cString: sqlite3_column_text(db2, 2))
                    let cb_feul = String(cString: sqlite3_column_text(db2, 3))
                    let cb_manual = String(cString: sqlite3_column_text(db2, 4))
                    let cb_img = String(cString: sqlite3_column_text(db2, 5))
                    tmpt.append(b_id)
                    tmpt.append(cb_cname)
                    tmpt.append(cb_siters)
                    tmpt.append(cb_feul)
                    tmpt.append(cb_manual)
                    tmpt.append(cb_img)
                    
                    main.append(tmpt)
                }
                data = true
                sqlite3_finalize(db2)
            }
            sqlite3_close(db1)
    }
          return main
   }
}
