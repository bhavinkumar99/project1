//
//  selectcar.swift
//  projectbhavin
//
//  Created by MAC2 on 06/02/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import UIKit

class selectcar: UITableViewCell {

    @IBOutlet weak var lblmanul: UILabel!
    @IBOutlet weak var lbloil: UILabel!
    @IBOutlet weak var lblfeul: UILabel!
    @IBOutlet weak var lblsiters: UILabel!
    @IBOutlet weak var lblname: UILabel!
    @IBOutlet weak var imgss: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
