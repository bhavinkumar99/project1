

import UIKit

private let reuseIdentifier = "Cell"

class CollectionViewController: UICollectionViewController {

    var final:[Any] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

       showdata()
       
    }

  

    override func numberOfSections(in collectionView: UICollectionView) -> Int {
       
        return 1
    }


    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
      
        return final.count
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)as! Collectionconcell
        let dic = final[indexPath.row] as! [String:Any]
        cell.textname1.text = dic["name"] as? String
        cell.textmodal2.text = dic["model"] as? String
        cell.textprize3.text = dic["prize"] as? String
        
        let imgName = dic["img"] as! String
        let urlStr = "http://localhost/MVCbjk/"
        let url = URL(string: urlStr + imgName)
        let imgData = NSData(contentsOf: url!)
        cell.img1.image = UIImage(data: imgData! as Data)
        return cell
    }

    func showdata()  {

        let url = URL(string: "http://localhost/MVCbjk/cardata.php")
        let request = URLRequest(url: url!)
        let session = URLSession.shared
        let detatask = session.dataTask(with: request) { (data2, respons, err) in
            let result = String(data: data2!, encoding: String.Encoding.utf8)
            print(result!)
            DispatchQueue.main.async {
                do{
                    let strbody = try JSONSerialization.jsonObject(with: data2!, options: [])as! [Any]
              
                    self.final = strbody
            
                    self.collectionView.reloadData()
                }catch{
                    
                }
            }
        }
        detatask.resume()
    }
}
