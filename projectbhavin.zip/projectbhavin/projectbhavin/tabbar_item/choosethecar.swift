import UIKit
import SSBouncyButton

class choosethecar: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet weak var tbl: UITableView!
    @IBOutlet weak var segm: UISegmentedControl!
  
    
    var Menu_VC = bhavin121()
    var Manu_Bool : Bool?
    
    let cardetail =
    [["c_name":"Mahindra KUV100","c_seater":"6 seater","fuel":"Full to Full","oil":"diesal","c_img":"mahindra.jpeg","manual":"manual","pakg1":"$2,300  120km-free","pakg2":"$5,500  240km-free","pakg3":"$12,400   Unlimited"],
   ["c_name":"Oddi","c_seater":"5 seater","fuel":"Full to Full","oil":"diesal","c_img":"m1.jpeg","manual":"manual","pakg1":"$1,590  120km-free","pakg2":"$4,500  240km-free","pakg3":"$12,000   Unlimited"],
    ["c_name":"Mercedes1","c_seater":"7 seater","fuel":"Full to Full","oil":"diesal","c_img":"m2.jpeg","manual":"manual","pakg1":"$2,900  120km-free","pakg2":"$5,400  240km-free","pakg3":"$15,400   Unlimited"],
    ["c_name":"Mercedes2","c_seater":"5 seater","fuel":"Full to Full","oil":"diesal","c_img":"m1.jpeg","manual":"manual","pakg1":"$2,200  120km-free ","pakg2":"$5,100  240km-free","pakg3":"$10,400   Unlimited"],
    ["c_name":"Mercedes3","c_seater":"5 seater","fuel":"Full to Full","oil":"diesal","c_img":"m1.jpeg","manual":"manual","pakg1":"$2,800  120km-free ","pakg2":"$6,500  240km-free","pakg3":"$14,400  Unlimited"]];
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1;
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cardetail.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
       let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)as! choosecell
        
        let button = UIButton(type: .custom)
        button.frame = CGRect(x: cell.frame.size.width - 46, y: 0, width: 46, height: 17)
        button.setImage(UIImage(named: "iw1.png"), for: .normal)
        button.addTarget(self, action: #selector(self.test), for: .touchUpInside)
        button.tag = indexPath.row
        cell.addSubview(button)
        
        let dic = cardetail[indexPath.row]
        cell.carname.text = dic["c_name"];
        cell.fuel.text = dic["fuel"];
        cell.oil.text = dic["oil"];
        cell.manual.text = dic["manual"];
        cell.seater.text = dic["c_seater"];
        cell.button1.setTitle(dic["pakg1"], for: .normal)
        cell.button2.setTitle(dic["pakg2"], for: .normal)
        cell.button3.setTitle(dic["pakg3"], for: .normal)
        cell.img.image = UIImage(named: dic["c_img"]!)
        
        
            cell.bookbut.tag = indexPath.row
            cell.bookbut.addTarget(self, action: #selector(self.test1), for: .touchUpInside)
  
       
            /*cell.button1.tag = indexPath.row
            cell.button1.addTarget(self, action: #selector(self.but1), for: .touchUpInside)
      
            cell.button2.tag = indexPath.row
        cell.button2.addTarget(self, action: #selector(self.but2), for: .touchUpInside)
        
            cell.button3.tag = indexPath.row
            cell.button3.addTarget(self, action: #selector(self.but3), for: .touchUpInside)*/
        
        
         return cell
        }
  
    @objc func test(sender: UIButton)  {
        
        var disc = cardetail[sender.tag] as [String:Any]
    
        let indexpath = IndexPath(row: sender.tag, section:0 )
        if let cell = tbl.cellForRow(at: indexpath) as? choosecell {
            let imgdata = cell.img.image?.pngData()
            
            let base64 = imgdata?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters);
            
            let url = URL(string: "http://localhost/whishlistbjk/Insertdetail.php")
            cell.carname.text = (disc["c_name"] as! String)
            cell.seater.text = (disc["c_seater"] as! String)
            cell.fuel.text = (disc["fuel"]as! String)
            cell.oil.text = (disc["oil"] as! String)
            cell.manual.text = (disc["manual"] as! String)
            disc["c_img"] = base64
            
            let btnText1 = cell.button1.titleLabel?.text
            disc["pakg1"] = btnText1
            
            let btnText2 = cell.button2.titleLabel?.text
            disc["pakg2"] = btnText2
            
            let btnText3 = cell.button3.titleLabel?.text
            disc["pakg3"] = btnText3
            
            cell.img.image = UIImage(named: base64!)
            DispatchQueue.main.async {
                do{
                    let strbody = try JSONSerialization.data(withJSONObject: disc, options: [])
                    var request = URLRequest(url: url!)
                    request.addValue(String(strbody.count), forHTTPHeaderField: "Content-Length")
                    request.httpBody = strbody
                    request.httpMethod = "POST"
                    
                    let session = URLSession.shared
                    let detatask = session.dataTask(with: request, completionHandler: { (data4, resp, err) in
                        let result = String(data: data4!, encoding: String.Encoding.utf8);
                       print(result!)
                    })
                    
                    detatask.resume()
                }catch{
                    
                }
                
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 270;
    }
 override func viewDidLoad() {
        super.viewDidLoad()
        Getdata()
        let button = UIButton(type: .custom)
        button.frame = CGRect(x: 16, y: 20, width: 46, height: 30)
        button.setImage(UIImage(named: "back.png"), for: .normal)
        button.addTarget(self, action: #selector(self.back), for: .touchUpInside)
        self.view.addSubview(button)
        
        Menu_VC = self.storyboard?.instantiateViewController(withIdentifier: "bhavin121") as! bhavin121
    }
    @IBAction func segValueChanged(_ sender: UISegmentedControl) {
        
    
        if segm.selectedSegmentIndex == 2 {
             Show_Menu()
        }else{
            Hide_Menu()
        }
    }
    func Show_Menu() {
        
        self.tbl.isHidden = true
        self.Menu_VC.view.frame = CGRect(x: 0, y: 90, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
        self.addChild(self.Menu_VC)
        self.view.addSubview(self.Menu_VC.view)
        self.Manu_Bool = false
    }
    func Hide_Menu()  {
        
        self.tbl.isHidden = false
        self.Menu_VC.view.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 90, width:  UIScreen.main.bounds.size.width, height:  UIScreen.main.bounds.size.height)
        self.Menu_VC.view.removeFromSuperview()
         Manu_Bool = true
    }
    @objc func back(sender: UIButton)  {
        
        let str = self.storyboard?.instantiateViewController(withIdentifier: "home")
        self.navigationController?.pushViewController(str!, animated: true)
        
      }
    @objc func test1(sender: UIButton){
        
        let imge = cardetail[sender.tag]
    
        let indexpath = IndexPath(row:sender.tag, section: 0)
        let cell = tbl.cellForRow(at:indexpath) as! choosecell
        let imgData = cell.img.image?.pngData()
        var baseStr = imgData?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
    
        let db = bookingdetail()
        
        let cb_cname = imge["c_name"];
        let cb_siters = imge["c_seater"];
        let cb_feul = imge["fuel"];
        let cb_manual = imge["manual"];
        let cb_img = imge["c_img"];
        
        print(cb_cname!)
        print(cb_siters!)
        print(cb_feul!)
        print(cb_manual!)
        print(cb_img!)
        
        let strquery = "insert into bookcar(cb_cname,cb_siters,cb_feul,cb_manual,cb_img)values('\(cb_cname!)','\(cb_siters!)','\(cb_feul!)','\(cb_manual!)','\(baseStr!)')";
   //  print(strquery)
        let st = db.dml(query: strquery);
        print(st)
         if st == true {
          print("insert");
   }
        else
    {
            print("empty");
            
        }
        
        let url = URL(string: "http://localhost/projectbhavin/bookcar.php");
        let stbody = "c_name=\(cell.carname.text!)&c_seater=\(cell.seater.text!)&fuel=\(cell.fuel.text!)&oil=\(cell.oil.text!)&c_img=\(baseStr)&manual=\(cell.manual.text!)&pakg1=\(cell.button1.titleLabel?.text!)&pakg2=\(cell.button2.titleLabel?.text!)&pakg3=\(cell.button3.titleLabel?.text!)";
        print(stbody)
        var request = URLRequest(url: url!)
        request.addValue(String(stbody.count), forHTTPHeaderField: "Content-length")
        request.httpBody = stbody.data(using: String.Encoding.utf8);
        request.httpMethod = "POST"
        let session = URLSession.shared;
        let regtask = session.dataTask(with: request) { (data1, respons, err) in
            DispatchQueue.main.async {
                let respons = String(data: data1!, encoding: String.Encoding.utf8);
                
                print(respons!);
                if respons == "Inserted"
                {
                    let alt = UIAlertController(title: "Messege", message: "Congretulation", preferredStyle: .alert)
                    let ok = UIAlertAction(title: "ok", style: .default, handler: { (next) in
               })
                    alt.addAction(ok)
                    self.present(alt, animated: true, completion: nil);
              }
                else{
                    
                }
            }
        }
        regtask.resume()
    }
  }
    var arr:[Any] = []
    
    func Getdata()  {
        let query = "select * from bookcar"
        let db = bookingdetail()
        arr = db.getdata(query: query)
        }


 /*   func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)as! choosecell
        
       
            if cell.button1.tag == 101 {
            let tap = UITapGestureRecognizer(target: self, action: #selector(self.but1))
                
            }else if cell.button2.tag == 102{
             let tap = UITapGestureRecognizer(target: self, action: #selector(self.but2))
                
            }else if cell.button3.tag == 103{
             let tap = UITapGestureRecognizer(target: self, action: #selector(self.but3))
            }
     }
    @objc func but1(sender: UIButton)  {
        let indexpath = IndexPath(row: sender.tag, section:0 )
        if let cell = tbl.cellForRow(at: indexpath) as? choosecell {
            cell.button1.layer.borderWidth = 2
            cell.button1.layer.borderColor = UIColor.red.cgColor
            cell.button2.isHidden = true
            cell.button3.isHidden = true
        }
    }
    @objc  func but2(sender: UIButton)  {
        let indexpath = IndexPath(row: sender.tag, section:0 )
        if let cell = tbl.cellForRow(at: indexpath) as? choosecell {
            cell.button2.layer.borderWidth = 2
            cell.button2.layer.borderColor = UIColor.yellow.cgColor
            cell.button1.isHidden = true
            cell.button3.isHidden = true
        }
    }
    @objc  func but3(sender:UIButton)  {
        let indexpath = IndexPath(row: sender.tag, section:0 )
        if let cell = tbl.cellForRow(at: indexpath) as? choosecell {
            cell.button3.layer.borderWidth = 2
            cell.button3.layer.borderColor = UIColor.orange.cgColor
            cell.button1.isHidden = true
            cell.button2.isHidden = true
            
        }
    }*/
    

