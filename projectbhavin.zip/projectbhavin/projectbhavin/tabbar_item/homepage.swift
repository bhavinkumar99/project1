


import UIKit

class homepage: UIViewController,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate {
    let dpikar = UIDatePicker();
    
    @IBOutlet weak var textbox3: UITextField!
    @IBOutlet weak var textbox2: UITextField!
    @IBOutlet weak var textbox1: UITextField!
    let arr = ["Mumbai","Dilhi","Aahmdabad","Varansi","Baroda","Navsari","Pune","Surat","Valsad","Boisar"];
    
    var manuarr = [["image":"home.png","name":"Home"],["image":"profi.png","name":"MY profile"],["image":"newoffer.png","name":"New offers"],["image":"setting.png","name":"Setting"]];
    var manuview = UIView()
    var manutable = UITableView()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        createtool1()
        createtool()
        manubut()
        getvalue()
        self.tabBarController?.tabBar.isHidden = false
     
      
        
    }
    func getvalue()  {
        let strpath = NSSearchPathForDirectoriesInDomains(.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true);
        let path = strpath[0]
        let fullpath = path.appending("/login.plist")
        let file = FileManager()
        if file.fileExists(atPath: fullpath)
        {
            let dic = ["image":"profi.png","name":"Login"]
            manuarr.append(dic)
            logout()
        }
        else{
            let dic1 = ["image":"profi.png","name":"Logout"]
            manuarr.append(dic1)
            
        }
    }
    func manubut()  {
        let but = UIButton(type: .custom)
        but.frame = CGRect(x: 16, y: 20, width: 46, height: 30)
        but.setImage(UIImage(named: "manu.png"), for: .normal)
        but.addTarget(self, action: #selector(self.manu), for: .touchUpInside)
        self.view.addSubview(but)
    }
   override func viewDidAppear(_ animated: Bool) {
        manuview = UIView(frame: self.view.bounds)
        manuview.backgroundColor = UIColor.darkGray;
        manuview.alpha = 0.0;
        self.view.addSubview(manuview)
        
        let tapgesture = UITapGestureRecognizer(target: self, action: #selector(self.tap))
        manuview.isUserInteractionEnabled = true
        manuview.addGestureRecognizer(tapgesture)
        manutable = UITableView(frame: CGRect(x: -200, y: 60, width: 200, height: self.view.frame.size.height), style: .grouped)
        manutable.tag = 009
        manutable.delegate = self
        manutable.dataSource = self
        manutable.backgroundColor = UIColor.orange
        self.view.addSubview(manutable)
    }
    @objc func tap(sender: UITapGestureRecognizer) {
        
        manuview.alpha = 0.0
        UITableView.beginAnimations(nil, context: nil)
        UITableView.setAnimationDuration(0.5)
        manutable.frame = CGRect(x: -200, y: 60, width: 200, height: self.view.frame.size.height)
        UITableView.commitAnimations()
    }
    
    @objc func manu(sender: UIBarButtonItem)  {
        
        manuview.alpha = 0.5
        UITableView.beginAnimations(nil, context: nil)
        UITableView.setAnimationDuration(0.5)
        manutable.frame = CGRect(x: 0, y: 60, width: 200, height: self.view.frame.size.height)
        UITableView.commitAnimations()
    }
    
    
    @IBAction func button(_ sender: UIButton) {
        let table = UITableView(frame:CGRect(x: 0, y:256 , width: 375, height: 248), style: .grouped);
        table.delegate = self;
        table.dataSource = self;
        self.view.addSubview(table);
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        if tableView.tag == 009 {
            return 1;
        }else{
           return 1;
        }
       
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView.tag == 009 {
            return manuarr.count
        }else{
            return arr.count
        }
   }
 func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView.tag == 009 {
            tableView.register(UITableViewCell.self, forCellReuseIdentifier: "manu")
            let cell = tableView.dequeueReusableCell(withIdentifier: "manu", for: indexPath)
            let dic = manuarr[indexPath.row]
            let img = dic["image"]
            let name = dic["name"]
            cell.textLabel?.text = name
            cell.imageView?.image = UIImage(named: img!)
            self.view.addSubview(cell)
            return cell
            
        }else{
            tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath);
            cell.textLabel?.text = String(arr[indexPath.row]);
            
            return cell;
        }
   }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
      
       textbox1.text = arr[indexPath.row]
        tableView.isHidden = true
        }
   
    func logout() {
        
        let file = FileManager()
        if file.fileExists(atPath: getPath()) {
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            var arr = disc["record"] as! [[String:Any]]
            if arr.count == 1{
                arr.removeAll()
                disc["record"] = arr
                let finalDisc = NSDictionary(dictionary: disc)
                finalDisc.write(toFile: getPath(), atomically: true)
                let comp = self.storyboard?.instantiateViewController(withIdentifier: "login") as! login_password
                self.navigationController?.pushViewController(comp, animated: true)
            }
        }
    }
    func getPath() -> String {
        
        let strpath = NSSearchPathForDirectoriesInDomains(.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true)
        let path = strpath[0]
        let fullpath = path.appending("/login.plist")
        print(fullpath);
        return fullpath
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView.tag == 009 {
            
        }
        return 50;
    }
    @IBAction func search(_ sender: Any) {
        
        let click = self.storyboard?.instantiateViewController(withIdentifier: "search")as! choosethecar
        self.navigationController?.pushViewController(click, animated: true);
    }
    func createtool()  {
        let bar = UIToolbar()
        bar.sizeToFit()
        let done = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(self.showToolbar))
        bar.setItems([done], animated: false)
        textbox2.inputAccessoryView = bar
        textbox2.inputView = dpikar
        dpikar.datePickerMode = .dateAndTime
    }
    func createtool1()  {
        let bar1 = UIToolbar()
        bar1.sizeToFit()
        let done = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(self.showtool1));
        bar1.setItems([done], animated: false)
        textbox3.inputAccessoryView = bar1
        textbox3.inputView = dpikar
        dpikar.datePickerMode = .dateAndTime
        
    }
    @objc func showtool1()  {
        let dt = dpikar.date
        let frm = DateFormatter()
        frm.dateFormat = "dd-MM-yyyy:hh-mm-ss"
        textbox3.text = frm.string(from: dt)
        self.view.endEditing(true)
    }
    @objc func showToolbar()  {
        let dt = dpikar.date
        let frm = DateFormatter()
        frm.dateFormat = "dd-MM-yyyy:hh-mm-ss"
        textbox2.text = frm.string(from: dt)
        self.view.endEditing(true)
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        self.view.endEditing(true)
    }
}
