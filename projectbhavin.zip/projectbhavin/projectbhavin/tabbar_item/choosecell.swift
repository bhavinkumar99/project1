//
//  choosecell.swift
//  projectbhavin
//
//  Created by MAC2 on 12/01/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import UIKit

class choosecell: UITableViewCell {
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var button3: UIButton!
    @IBOutlet weak var button2: UIButton!
    @IBOutlet weak var button1: UIButton!
    @IBOutlet weak var manual: UILabel!
    @IBOutlet weak var oil: UILabel!
    @IBOutlet weak var fuel: UILabel!
    @IBOutlet weak var seater: UILabel!
    @IBOutlet weak var carname: UILabel!
   
    @IBOutlet weak var bookbut: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
