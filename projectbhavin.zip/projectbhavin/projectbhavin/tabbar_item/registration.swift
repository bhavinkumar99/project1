//
//  registration.swift
//  projectbhavin
//
//  Created by MAC2 on 09/01/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import UIKit
import TextFieldEffects

class registration: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource,UITextFieldDelegate {
    
    let state = ["Gujarat","Maharashtra","Hariyana",
"Utter pradesh","Odisha","Rajashthan","Madhya pradesh","Tamilnadu","Keral","panjab","Pashim Bangal","Jammu-Kashmir"];
    
    
    @IBOutlet weak var pikar: UIPickerView!

    @IBOutlet weak var dpikar: UIDatePicker!
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        dpikar.isHidden = false
        pikar.isHidden = false
        return false;
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1;
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return state.count
    }
    

    @IBOutlet weak var fname: UITextField!
    @IBOutlet weak var lname: UITextField!
    @IBOutlet weak var location: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var mobileno: UITextField!
    @IBOutlet weak var pincode: UITextField!
    @IBOutlet weak var Dob: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

      pikar.isHidden = true
        dpikar.isHidden = true
        let dt = Date();
        let frm = DateFormatter();
        frm.dateFormat = "dd-MM-yyyy"
        Dob.text = frm.string(from: dt)
    
      let back = UIButton(type: .custom)
        back.frame = CGRect(x: 16, y: 9, width: 48, height: 30);
        back.addTarget(self, action: #selector(self.test), for: .touchUpInside);
        back.setImage(UIImage(named: "back.png"), for: .normal)
        self.view.addSubview(back)

    }
    @objc func test()  {
        let but = self.storyboard?.instantiateViewController(withIdentifier: "login")
        self.navigationController?.popToRootViewController(animated: true)
        
    }
    
    
    @IBAction func registedbut(_ sender: UIButton) {
        
        let url = URL(string: "http://localhost/projectbhavin/reg.php");
        let stbody = "fname=\(fname.text!)&lname=\(lname.text!)&location=\(location.text!)&email=\(email.text!)&password=\(password.text!)&pincode=\(pincode.text!)&mobileno=\(mobileno.text!)&Dob=\(Dob.text!)";
        
        var request = URLRequest(url: url!)
        request.addValue(String(stbody.count), forHTTPHeaderField: "consent-length")
        request.httpBody = stbody.data(using: String.Encoding.utf8);
        request.httpMethod = "POST"
        let session = URLSession.shared;
        let regtask = session.dataTask(with: request) { (data1, respons, err) in
            DispatchQueue.main.async {
                let respons = String(data: data1!, encoding: String.Encoding.utf8);
                
                print(respons);
                if respons == "Inserted"
                {
                    let alt = UIAlertController(title: "Messege", message: "Congretulation", preferredStyle: .alert)
                    let ok = UIAlertAction(title: "ok", style: .default, handler: { (next) in
                        let nev = self.storyboard?.instantiateViewController(withIdentifier: "login")
                        self.navigationController?.pushViewController(nev!, animated: true)
                        
                    })
                    alt.addAction(ok)
                    self.present(alt, animated: true, completion: nil);
        
                }
                else{
                    
                }
            }
        }
        regtask.resume()
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return state[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        location.text = state[row];
        pikar.isHidden = true
       // pikar.reloadAllComponents()
    }

    @IBAction func dpikaraction(_ sender: Any) {
        let dt = dpikar.date
        dpikar.datePickerMode = .date
        let frm = DateFormatter();
        frm.dateFormat = "dd-MM-yyyy";
        Dob.text = frm.string(from: dt);
        dpikar.isHidden = true;
        
    }
}
