

import UIKit

class searchpage: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
  
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var text3: UITextField!
    @IBOutlet weak var text2: UITextField!
    @IBOutlet weak var text1: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    func jsonpar()  {
        let imgview = img.image?.pngData()
        var base64 = (imgview?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters))
        let url = URL(string: "http://localhost/MVCbjk/Insertdetail.php");
        let dic = ["name":text1.text!,"model":text2.text!,"prize":text3.text!,"img":base64];
            do{
               let body = try JSONSerialization.data(withJSONObject: dic, options: [])
               
                var request = URLRequest(url: url!)
                request.addValue(String(body.count), forHTTPHeaderField: "Content-Length")
                request.httpBody = body
                request.httpMethod = "POST"
            
        let session = URLSession.shared
        let detatask = session.dataTask(with: request) { (data1, respons, err) in
                    
        let result = String(data: data1!, encoding: String.Encoding.utf8)
                    print(result!)
         
            }
       detatask.resume()
            }catch{
                
        }
    }
   
        @IBAction func upload(_ sender: Any) {
        let picker = UIImagePickerController()
        picker.sourceType = .photoLibrary
        picker.delegate = self
        self.present(picker, animated: true, completion: nil)
 }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let img1 = info[UIImagePickerController.InfoKey.originalImage];
        img.image = img1 as? UIImage
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func Insertdetail(_ sender: Any) {
        jsonpar()
        
    }
    
    @IBAction func nextbut(_ sender: Any) {
        let str = self.storyboard?.instantiateViewController(withIdentifier: "call");
        self.navigationController?.pushViewController(str!, animated: true)
        
    }
}
