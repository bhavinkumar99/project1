

import UIKit
import TextFieldEffects

class login_password: UIViewController {

    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var textbox1: UITextField!
    @IBOutlet weak var lbl1: UILabel!
    @IBOutlet weak var textbox2: UITextField!
    @IBOutlet weak var lbl2: UILabel!
    var jsonData : [[String:Any]] = []

    override func viewDidLoad() {
        super.viewDidLoad()
 //   self.tabBarController?.tabBar.isHidden = true
        ///createLogin()
    }
   @IBAction func emailbox(_ sender: UITextField) {
   
        if isvalidemail(email: textbox1.text!) {
            
            textbox1.rightViewMode = .never
            textbox1.clipsToBounds = true;
            textbox1.layer.borderWidth = 1;
            textbox1.layer.borderColor = UIColor.green.cgColor;
        }
        else{
            
            textbox1.rightViewMode = .whileEditing
            textbox1.clipsToBounds = true;
            textbox1.layer.borderWidth = 1;
            textbox1.layer.borderColor = UIColor.red.cgColor;
        }
        
        lbl1.text = "abcd123@gmail.com"
         }
    
    @IBAction func passwordbox(_ sender: UITextField) {

        
        if isvalidpassword(pass: textbox2.text!) {
            textbox2.rightViewMode = .never
            textbox2.clipsToBounds = true;
            textbox2.layer.borderWidth = 1;
            textbox2.layer.borderColor = UIColor.green.cgColor;
        }
        else{
            
            textbox2.rightViewMode = .whileEditing
            textbox2.clipsToBounds = true;
            textbox2.layer.borderWidth = 1;
            textbox2.layer.borderColor = UIColor.red.cgColor;
        }
        lbl2.text = "bbb***154***"
    }
    
    @IBAction func login(_ sender: UIButton) {
        
       checkLogin()
        
    }
       
        func checkLogin(){
            
            let log = String("http://localhost/projectbhavin/login.php?email=\(textbox1.text!)&password=\(textbox2.text!)");
            let url = URL(string: log)
            let request = URLRequest(url: url!)
            let session = URLSession.shared;
            let dataTask = session.dataTask(with: request) { (data1, respons, err) in
            
                let result = String(data: data1!, encoding: String.Encoding.utf8)
                print(result!)
                do{
                    self.jsonData = try JSONSerialization.jsonObject(with: data1!, options: []) as! [[String:Any]]
                    DispatchQueue.main.async {
                        
                        if self.jsonData.count == 1{
                            
                            self.storeLogin()
                        }else{
                            let alt = UIAlertController(title: "Sorry", message: "Please registration your id", preferredStyle: .alert)
                            let ok = UIAlertAction(title: "ok", style: .default, handler: { (test) in
                                let chenge = self.storyboard?.instantiateViewController(withIdentifier: "login")
                                self.navigationController?.pushViewController(chenge!, animated: false)
                                
                            })
                            alt.addAction(ok)
                            self.present(alt, animated: true, completion: nil)
                            
                        }
                    }
                }catch{
                    
                }
            }
            dataTask.resume()
        }
    func storeLogin() {
        
        let file = FileManager()
        if file.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            var arr = disc["record"] as! [[String:Any]]
            arr = jsonData
            disc["record"] = arr
            let finalDisc = NSDictionary(dictionary: disc)
            finalDisc.write(toFile: getPath(), atomically: true)
            let comp = self.storyboard?.instantiateViewController(withIdentifier: "home")
            self.navigationController?.pushViewController(comp!, animated: true)
            
        }
    }
    func createLogin() {
        
        let file = FileManager()
        if !file.fileExists(atPath: getPath())
        {
            let arr : [[String:Any]] = []
            let dic : [String:Any] = ["record":arr]
            let finalDisc = NSDictionary(dictionary: dic)
            finalDisc.write(toFile: getPath(), atomically: true)
        }
    }
    func getPath() -> String {
        
        let strpath = NSSearchPathForDirectoriesInDomains(.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true)
        let path = strpath[0]
        let fullpath = path.appending("/login.plist")
        print(fullpath);
        return fullpath
    }
    @IBAction func newregis(_ sender: UIButton) {
        
        let regis = self.storyboard?.instantiateViewController(withIdentifier: "next")as! registration
        self.navigationController?.pushViewController(regis, animated: true);
    }
    func isvalidemail(email: String) -> Bool {
        
        let emailregex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailtest = NSPredicate(format: "SELF MATCHES %@", emailregex);
        let result = emailtest.evaluate(with: email);
        return result;
    
    }
    
    func isvalidpassword(pass: String) -> Bool {
        let passregex = "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{8,}$"
        let passtest = NSPredicate(format: "SELF MATCHES %@", passregex);
        let result = passtest.evaluate(with: pass);
        return result;
    }
  
}
