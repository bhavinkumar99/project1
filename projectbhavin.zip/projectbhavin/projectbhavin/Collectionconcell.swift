//
//  Collectionconcell.swift
//  projectbhavin
//
//  Created by MAC2 on 05/02/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import UIKit

class Collectionconcell: UICollectionViewCell {
    
    @IBOutlet weak var textprize3: UILabel!
    @IBOutlet weak var textmodal2: UILabel!
    @IBOutlet weak var textname1: UILabel!
    @IBOutlet weak var img1: UIImageView!
}
