
import UIKit
import Alamofire
/*struct jsonparser:Decodable {
    let name:String
    let capital:String
    
    
}*/
class railapi: UIViewController,UITableViewDelegate,UITableViewDataSource {
  
    

    
    var finalarr:[Any] = []
    
  //  var searcharr = [jsonparser]()
    
    
    @IBOutlet weak var tbl: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

       getdata()
    }
    func getdata()  {
        let url = URL(string: "http://restcountries.eu/rest/v2/all")
        let request = URLRequest(url: url!)
        let session = URLSession.shared
        let detatask = session.dataTask(with: request) { (data1, respons, error) in
       
                do{
                    let arr = try JSONSerialization.jsonObject(with: data1!, options: [])as! [String:Any]
                    DispatchQueue.main.async {
                        
                       self.finalarr = arr["name"]as! [Any]
                    self.tbl.reloadData()
                        
                        } 
                }catch{
                    
                    }
            
        }
        .resume()
        
        }
        
        
        
        
       /* let url = URL(string: "http://restcountries.eu/rest/v2/all")
      URLSession.shared.dataTask(with: url!) { (data1, respons, error) in
            do{
                if Error.self == nil{
                    self.searcharr = try JSONDecoder().decode([jsonparser].self, from: data1!)
                    for mainarr in self.searcharr{
                        print(mainarr.name)
                    }
                }
                
            }catch{
                
            }
        }.resume()*/
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return finalarr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)as! collcell
        let dic = finalarr[indexPath.row]as! [String:Any]
        
        cell.lblname.text = dic["name"]as! String
        return cell
    }
    }
   
        
        

    

