//
//  collcell.swift
//  projectbhavin
//
//  Created by MAC2 on 28/01/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import UIKit

class collcell: UITableViewCell {
    @IBOutlet weak var lblname: UILabel!
    
    @IBOutlet weak var lbldistance: UILabel!
    @IBOutlet weak var lblcode: UILabel!
    @IBOutlet weak var lblno: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
