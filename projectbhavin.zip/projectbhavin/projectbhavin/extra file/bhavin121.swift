//
//  bhavin121.swift
//  projectbhavin
//
//  Created by MAC2 on 28/01/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import UIKit

class bhavin121: UIViewController,UITableViewDelegate,UITableViewDataSource {
    let cararr = [["car_img":"images1.jpeg","car_name":"BMW","car_siters":"6 s"],["car_img":"images.jpeg","car_name":"Ford","car_siters":"7 s"],["car_img":"images1.jpeg","car_name":"TATA","car_siters":"6 s"],["car_img":"images2.jpeg","car_name":"Oddi","car_siters":"8 s"],["car_img":"images.jpeg","car_name":"SK","car_siters":"9 s"]];
    
    
 //   let arr1 = ["images1.jpeg","images1.jpeg","images1.jpeg","images1.jpeg"]
    let arr2 = ["images.jpeg","images.jpeg","images.jpeg","images.jpeg"]
    
    let arr = ["images2.jpeg","images2.jpeg","images2.jpeg","images2.jpeg"]
    let tableview = UITableView()
    

    @IBOutlet weak var seg: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()

        table()
        // Do any additional setup after loading the view.
    }
    
 
    @IBAction func segbutton(_ sender: UISegmentedControl) {
       table()
    }
    
    func table()  {
        
        let tbl1 = UITableView(frame: CGRect(x: 0, y: 55, width: 374, height: 612), style: .grouped)
        tbl1.delegate = self
        tbl1.dataSource = self
        self.view.addSubview(tbl1)
    }
   /* func table1()  {
        
        let tbl2 = UITableView(frame: CGRect(x: 0, y: 55, width: 374, height: 612), style: .plain)
        tbl2.delegate = self
        tbl2.dataSource = self
        self.view.addSubview(tbl2)
    }*/
  
    func numberOfSections(in tableView: UITableView) -> Int {
        
       return 1
       
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if seg.selectedSegmentIndex == 0{
            return cararr.count
        }
        else if seg.selectedSegmentIndex == 1{
            return arr.count
        }else{
            return arr2.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if seg.selectedSegmentIndex == 0 {
            tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            let dic = cararr[indexPath.row]
            cell.textLabel?.text =  dic["car_name"]
            cell.imageView?.image = UIImage(named: dic["car_img"]!)
            return cell
        }else if seg.selectedSegmentIndex == 1{
            tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            cell.imageView?.image = UIImage(named: arr[indexPath.row])
            return cell
        }else{
             tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            cell.imageView?.image = UIImage(named: arr2[indexPath.row])
            return cell
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    }
    
  


