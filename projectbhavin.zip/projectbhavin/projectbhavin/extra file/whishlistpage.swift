//
//  whishlistpage.swift
//  projectbhavin
//
//  Created by MAC2 on 24/01/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import UIKit

class whishlistpage: UIViewController {
    var xside = 20;
    var space = 50;
    var yside = 20;
    
    override func viewDidLoad() {
        super.viewDidLoad()
       /* let button = UIButton(type: .custom)
        button.frame = CGRect(x: 16, y: 20, width: 46, height: 30)
        button.setImage(UIImage(named: "back.png"), for: .normal)
        button.addTarget(self, action: #selector(self.back), for: .touchUpInside)
        self.view.addSubview(button)*/
       
        let scrview1 = UIScrollView(frame: self.view.bounds)
        
            
        for i in 1...300 {
       
            let scrview = UIScrollView(frame: CGRect(x: 0, y: yside, width: 1000, height:70))
            scrview.contentSize = CGSize(width: 2000, height: 50)
              scrview1.addSubview(scrview)
            yside = yside + space
            xside = 0
        for i in 1...20 {
            
            let but = UIButton(type: .custom)
            but.frame = CGRect(x: xside, y: 25, width: 53, height: 37)
            but.setImage(UIImage(named: "home.png"), for: .normal)
            xside = xside + space
            scrview.addSubview(but)
            
            }
            
        }
      scrview1.contentSize = CGSize(width: 375, height: 1000)
       
        self.view.addSubview(scrview1)
    }
    
      /*  func back()  {
        let backbut = self.storyboard?.instantiateViewController(withIdentifier: "home")as! homepage
        self.navigationController?.pushViewController(backbut, animated: true)
    
        
    }*/
    
    
  
    
    }
    
    
    
    

