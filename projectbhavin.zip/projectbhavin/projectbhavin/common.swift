//
//  common.swift
//  projectbhavin
//
//  Created by MAC2 on 16/01/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import UIKit

class common: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
   class func createframe(frm : CGRect) -> UINavigationBar {
        let navbar = UINavigationBar(frame: frm)
        navbar.tintColor = UIColor.white
        return navbar
        
    }

 
}
