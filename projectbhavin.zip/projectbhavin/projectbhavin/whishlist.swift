

import UIKit
import Alamofire
class whishlist: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    
    @IBOutlet weak var tbl: UITableView!
    var final:[[String:Any]] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

    storedata()
    }
    func storedata()  {
        Alamofire.request("http://localhost/whishlistbjk/cardata.php").responseJSON { response in
          //  print("Request: \(String(describing: response.request))")   // original url request
          //  print("Response: \(String(describing: response.response))") // http url response
          //  print("Result: \(response.result)")                         // response serialization result
            
            if let json = response.result.value {
               // print("JSON: \(json)")
           
            }
            
            if let data = response.data, let utf8Text = String(data: data, encoding: .utf8) {
               // print("Data: \(utf8Text)") // original server data as UTF8 string
                DispatchQueue.main.async {
                    do{
                        let arr = try JSONSerialization.jsonObject(with: data, options: []) as! [[String:Any]]
                        print(arr)
                        self.final = arr
                        self.tbl.reloadData()
                    }catch{
             
                    }
                }
           }
        }
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1;
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return final.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)as! whishlistcell
        var dis = final[indexPath.row]
        
        cell.name.text = (dis["c_name"]as! String)
        cell.sit.text = (dis["c_seater"]as! String)
        cell.feul.text = (dis["fuel"]as! String)
        cell.oil.text = (dis["oil"]as! String)
        cell.manual.text = (dis["manual"]as! String)
        cell.but1.setTitle(dis["pakg1"] as? String, for: UIControl.State.normal)
        cell.but2.setTitle((dis["pakg2"] as! String), for: UIControl.State.normal)
        cell.but3.setTitle((dis["pakg3"] as! String), for: UIControl.State.normal)
        
        let imgName = dis["c_img"] as! String
        let urlStr = "http://localhost/whishlistbjk/"
        let url = urlStr + imgName
        let finalUrl = URL(string: url)
        let imgData = NSData(contentsOf: finalUrl!)
        cell.whishimg.image = UIImage(data: imgData! as Data)
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
       final.remove(at: indexPath.row)
        tbl.reloadData()
    }
}
