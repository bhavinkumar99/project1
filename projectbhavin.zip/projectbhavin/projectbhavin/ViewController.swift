//
//  ViewController.swift
//  projectbhavin
//
//  Created by MAC2 on 08/01/19.
//  Copyright © 2019 MAC2. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true
       // self.tabBarController?.tabBar.isHidden = true
    }
    override func viewDidAppear(_ animated: Bool) {
        checkLogin()
    }
    func checkLogin() {
        
        let file = FileManager()
        if file.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            let arr = disc["record"] as! [[String:Any]]
            if arr.count == 1{
                
               let story = self.storyboard?.instantiateViewController(withIdentifier: "userTab")
                self.navigationController?.pushViewController(story!, animated: false)
            }
            else{
                let story = self.storyboard?.instantiateViewController(withIdentifier: "login") as! login_password
                self.navigationController?.pushViewController(story, animated: false)
                
            }
        }
    }
    func getPath() -> String {
        
        let strpath = NSSearchPathForDirectoriesInDomains(.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true)
        let path = strpath[0]
        let fullpath = path.appending("/login.plist")
        print(fullpath);
        return fullpath
    }

}

