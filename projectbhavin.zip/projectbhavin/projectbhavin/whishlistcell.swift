

import UIKit

class whishlistcell: UITableViewCell {

    @IBOutlet weak var but3: UIButton!
    @IBOutlet weak var but2: UIButton!
    @IBOutlet weak var but1: UIButton!
    @IBOutlet weak var manual: UILabel!
    @IBOutlet weak var oil: UILabel!
    @IBOutlet weak var feul: UILabel!
    @IBOutlet weak var sit: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var whishimg: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }

}
